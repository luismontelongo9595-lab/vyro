import Link from "next/link";
import { redirect } from "next/navigation";
import { headers } from "next/headers";
import { PrismaClient } from "@prisma/client";
import { auth } from "../../../auth";
import PageContainer from "../components/PageContainer";
import PageHeader from "../components/PageHeader";

const prisma = new PrismaClient();

export default async function MessagesPage() {
  const session = await auth.api.getSession({ headers: await headers() });
  if (!session) redirect("/sign-in");

  const currentUserId = session.user.id;

  const conversations = await prisma.conversation.findMany({
    where: {
      participants: {
        some: { userId: currentUserId },
      },
    },
    include: {
      participants: {
        select: {
          userId: true,
          lastReadAt: true,
          user: {
            select: {
              id: true,
              name: true,
              email: true,
              image: true,
              customImage: true,
            },
          },
        },
      },
      messages: {
        orderBy: { createdAt: "desc" },
        take: 1,
        select: {
          id: true,
          content: true,
          createdAt: true,
          senderId: true,
        },
      },
    },
    orderBy: { updatedAt: "desc" },
  });

  const inbox = conversations
    .filter((conversation) => conversation.participants.length === 2)
    .map((conversation) => {
      const otherParticipant = conversation.participants.find(
        (p) => p.userId !== currentUserId
      );

      const currentParticipant = conversation.participants.find(
        (p) => p.userId === currentUserId
      );

      const latestMessage = conversation.messages[0] ?? null;

      const unread =
        !!latestMessage &&
        latestMessage.senderId !== currentUserId &&
        (
          !currentParticipant?.lastReadAt ||
          new Date(latestMessage.createdAt) > new Date(currentParticipant.lastReadAt)
        );

      return {
        id: conversation.id,
        updatedAt: conversation.updatedAt,
        otherUser: otherParticipant?.user ?? null,
        latestMessage,
        unread,
      };
    });

  const headerRight = (
    <div className="inline-flex items-center rounded-full border border-[#a3b18a]/30 bg-white/50 px-4 py-2 text-sm font-medium text-[#5a7d5a] backdrop-blur-md">
      {inbox.length} conversation{inbox.length === 1 ? "" : "s"}
    </div>
  );

  return (
    <PageContainer>
      <PageHeader 
        title="My Messages"
        subtitle="Message History"
        rightContent={headerRight}
      />

      <div className="rounded-[2rem] border border-white/60 bg-white/40 backdrop-blur-lg shadow-xl shadow-stone-200/50 p-6 md:p-8">
        {inbox.length === 0 ? (
          <div className="w-full py-20 flex flex-col items-center justify-center bg-white/40 backdrop-blur-md rounded-3xl border border-white/60 shadow-xl shadow-stone-200/50">
            <span className="text-6xl mb-6 block">💬</span>
            <p className="text-xl font-semibold text-[#4a4a4a] mb-2">
              No conversations yet.
            </p>
            <p className="text-[#8a8a8a] mb-6">
            When you message another user from a book listing, your conversation will appear here.
            </p>
            <Link
              href="/dashboard"
              className="inline-flex items-center justify-center px-6 py-3 bg-[#bc8a5f] hover:bg-[#a47148] text-white font-bold rounded-full transition-all shadow-lg shadow-[#bc8a5f]/20"
            >
              Browse Catalog
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            {inbox.map((conversation) => (
              <Link
                key={conversation.id}
                href={`/messages/${conversation.id}`}
                className={`group block rounded-[1.5rem] border p-5 backdrop-blur-md transition-all shadow-lg shadow-stone-200/20 ${
                  conversation.unread
                    ? "border-[#a3b18a]/40 bg-[#f7f6f2]/80 hover:bg-white/80"
                    : "border-white/60 bg-white/40 hover:bg-white/60"
                }`}
              >
                <div className="flex items-center justify-between gap-4">
                  <div className="flex items-center gap-4 min-w-0">
                    <div className="h-14 w-14 shrink-0 overflow-hidden rounded-full border border-white/60 bg-[#e2d9c8]/50 shadow-sm flex items-center justify-center text-[#8a8a8a] font-bold">
                      {conversation.otherUser?.customImage || conversation.otherUser?.image ? (
                        <img
                          src={
                            conversation.otherUser?.customImage ||
                            conversation.otherUser?.image ||
                            ""
                          }
                          alt={conversation.otherUser?.name ?? "User"}
                          className="h-full w-full object-cover"
                        />
                      ) : (
                        <span>
                          {(conversation.otherUser?.name ?? "U").charAt(0).toUpperCase()}
                        </span>
                      )}
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <p
                          className={`truncate text-base ${
                            conversation.unread
                              ? "font-bold text-[#4a4a4a]"
                              : "font-semibold text-[#4a4a4a]"
                          }`}
                        >
                          {conversation.otherUser?.name ?? "Unknown user"}
                        </p>

                        {conversation.unread && (
                          <span className="inline-block h-2.5 w-2.5 rounded-full bg-[#bc8a5f]" />
                        )}
                      </div>

                      <p
                        className={`mt-1 truncate text-sm ${
                          conversation.unread ? "text-[#5c5c5c] font-medium" : "text-[#8a8a8a]"
                        }`}
                      >
                        {conversation.latestMessage?.content ?? "No messages yet"}
                      </p>
                    </div>
                  </div>

                  <div className="shrink-0 text-right">
                    <p className="text-xs text-[#8a8a8a]">
                      {new Date(conversation.updatedAt).toLocaleTimeString([], {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </p>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </PageContainer>
  );
}
