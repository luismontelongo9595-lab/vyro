import { redirect } from 'next/navigation'
import { headers } from 'next/headers'
import { auth } from '@/auth'

export default async function Home() {
  const session = await auth.api.getSession({
    headers: await headers(),
  })

  if (!session) {
    redirect('/sign-in')
  }

  redirect('/dashboard')
}